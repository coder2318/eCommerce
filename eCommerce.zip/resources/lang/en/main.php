<?php

return [
    'about' => 'About Us',
    'shop' => 'Shop',
    'cart' => 'Cart',
    'checkout' => 'Checkout'
];
