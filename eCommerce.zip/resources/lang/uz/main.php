<?php
return [
    'about' => 'Biz haqimizda',
    'shop' => 'Market',
    'cart' => 'Savat',
    'checkout' => 'Tolov'
];
