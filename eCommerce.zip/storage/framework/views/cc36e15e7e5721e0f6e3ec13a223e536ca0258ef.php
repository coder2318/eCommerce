<div class="container m-10">
    <table class="table table-info">
        <thead>
            <tr >
                <th>№</th>
                <th>Fullname</th>
                <th>All Price</th>
                <th>Status</th>
                <th>Payment Type</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-info">
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                    <td>$<?php echo e($order->all_price); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->payment_type); ?></td>
                    <td><a href="<?php echo e(route('order.details', ['order_id' => $order->id])); ?>" class="btn btn-success">Show</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views/livewire/my-orders-component.blade.php ENDPATH**/ ?>