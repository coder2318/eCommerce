

<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-10 col-lg-8 col-xl-6">
                <div class="card">
                    <div class="card-header">
                      <i class="fa fa-align-justify"></i> <?php echo e(__('Create Note')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('product.update', ['product' => $product->id])); ?>" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo $__env->make('dashboard.products.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\products\edit.blade.php ENDPATH**/ ?>