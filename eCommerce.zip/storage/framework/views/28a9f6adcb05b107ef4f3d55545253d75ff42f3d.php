

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
  <div class="fade-in">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header"><h4>Create BREAD</h4></div>
            <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        </div>
                    </div>
                <?php endif; ?>            
                <div class="row">
                    <div class="col-6">
                        <form method="POST" action="<?php echo e(route('bread.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="marker" value="selectModel" type="hidden">
                            <div class="form-group">
                                <label>Table name in database</label>
                                <input 
                                    type="text"
                                    placeholder="Table name"
                                    name="model"
                                    class="form-control"
                                >
                            </div>
                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Select
                            </button>
                            <a 
                                href="<?php echo e(route('bread.index')); ?>"
                                class="btn btn-primary"
                            >
                                Return
                            </a>
                        </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\form\create.blade.php ENDPATH**/ ?>