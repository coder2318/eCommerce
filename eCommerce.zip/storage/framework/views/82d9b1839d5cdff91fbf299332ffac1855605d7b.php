

<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-10 col-lg-8 col-xl-6">
                <div class="card">
                    <div class="card-header">
                      <i class="fa fa-align-justify"></i> Note: <?php echo e($note->title); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('logout')); ?>"> <?php echo csrf_field(); ?><button class="btn btn-primary"><?php echo e(__('Logout')); ?></button></form> 
                        <br>
                        <h4>Author:</h4>
                        <p> <?php echo e($note->user->name); ?></p>
                        <h4>Title:</h4>
                        <p> <?php echo e($note->title); ?></p>
                        <h4>Content:</h4> 
                        <p><?php echo e($note->content); ?></p>
                        <h4>Applies to date:</h4> 
                        <p><?php echo e($note->applies_to_date); ?></p>
                        <h4> Status: </h4>
                        <p>
                            <span class="<?php echo e($note->status->class); ?>">
                              <?php echo e($note->status->name); ?>

                            </span>
                        </p>
                        <h4>Note type:</h4>
                        <p><?php echo e($note->note_type); ?></p>
                        <a href="<?php echo e(route('notes.index')); ?>" class="btn btn-block btn-primary"><?php echo e(__('Return')); ?></a>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\notes\noteShow.blade.php ENDPATH**/ ?>