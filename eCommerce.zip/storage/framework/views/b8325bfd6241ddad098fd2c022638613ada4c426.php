

<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                      <i class="fa fa-align-justify"></i><?php echo e(__('Products')); ?></div>
                    <div class="card-body">
                        <div class="row">
                          <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary m-2"><?php echo e(__('Add Products')); ?></a>
                        </div>
                        <br>
                        <table class="table table-responsive-sm table-striped">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Price</th>
                            <th>Category</th>
                            <th>Short Description</th>
                            <th>Status</th>
                            <th></th>
                            <th></th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><strong><?php echo e($product->name); ?></strong></td>
                              <td><img src="<?php echo e(asset('assets/images/products/'.$product->image)); ?>" width="70" alt="<?php echo e($product->name); ?>"></td>
                              <td><?php echo e($product->price); ?></td>
                              <td><?php echo e($product->category->name); ?></td>
                              <td><strong><?php echo e($product->short_description); ?></strong></td>
                              <td>
                                  <span class="primary">
                                      <?php echo e($product->status); ?>

                                  </span>
                              </td>
                              <td>
                                <a href="<?php echo e(url('/product/' . $product->id)); ?>" class="btn btn-block btn-primary">View</a>
                              </td>
                              <td>
                                <a href="<?php echo e(url('/product/' . $product->id . '/edit')); ?>" class="btn btn-block btn-primary">Edit</a>
                              </td>
                              <td>
                                <form action="<?php echo e(route('product.destroy', $product->id )); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-block btn-danger">Delete</button>
                                </form>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      <?php echo e($products->links()); ?>

                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\products\index.blade.php ENDPATH**/ ?>