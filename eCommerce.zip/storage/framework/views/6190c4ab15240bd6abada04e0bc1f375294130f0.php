

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h4>Send Email: <?php echo e($template->name); ?></h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('mailSend', ['id' => $template->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label>Email adress</label>
                                <input class="form-control" type="text" placeholder="Email adress" name="email" required autofocus/>
                            </div>
                            <button class="btn btn-success" type="submit">Send</button>
                            <a href="<?php echo e(route('mail.index')); ?>" class="btn btn-primary">Return</a> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\email\send.blade.php ENDPATH**/ ?>