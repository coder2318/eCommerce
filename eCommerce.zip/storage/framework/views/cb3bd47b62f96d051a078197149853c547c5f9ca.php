

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
  <div class="fade-in">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header"><h4>Show <?php echo e($form->name); ?></h4></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <table class="table">
                            <tbody>
                                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($column['name']); ?>

                                        </td>
                                        <td>
                                            <?php
                                              if( $column['type'] == 'default'){
                                                echo $column['value'];
                                              }elseif( $column['type'] == 'file'){
                                                echo '<a href="' . $column['value'] . '" class="btn btn-primary" target="_blank">Open file</a>';
                                              }elseif( $column['type'] == 'image' ){
                                                echo '<img src="' . $column['value'] . '" style="max-width:200px;max-height:200px;">';
                                              }


                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a 
                            href="<?php echo e(route('resource.index', $form->id)); ?>"
                            class="btn btn-primary"
                        >
                            Return
                        </a>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\resource\show.blade.php ENDPATH**/ ?>