<div class="wrap-icon-section minicart">
    <a href="#" class="link-direction">
        <i class="fa fa-shopping-basket" aria-hidden="true"></i>
        <div class="left-info">
            <?php if($cart): ?>

            <span class="index"><?php echo e($cart->sum('quantity')); ?> items</span>

            <?php endif; ?>
            <span class="title">CART</span>
        </div>
    </a>
</div>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views/livewire/cart-count-component.blade.php ENDPATH**/ ?>