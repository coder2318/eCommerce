

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
  <div class="fade-in">
    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header"><h4>Create BREAD</h4></div>
            <div class="card-body">
                <?php if(Session::has('message')): ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                        </div>
                    </div>
                <?php endif; ?>  

                <form method="POST" action="<?php echo e(route('bread.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input name="marker" value="createForm" type="hidden">
                    <input type="hidden" name="model" value="<?php echo e($model); ?>"> 

                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Form name</label>
                                <input 
                                    type="text"
                                    name="name"
                                    placeholder="Form name"
                                    class="form-control"
                                    required
                                >
                            </div>
                            <div class="form-group">
                                <label>Records on one page of table</label>
                                <input 
                                    type="number"
                                    name="pagination"
                                    placeholder="Records on one page of table"
                                    class="form-control"
                                    value="10"
                                    required
                                >
                            </div>
                            <div class="form-check checkbox mt-3">
                              <input class="form-check-input" type="checkbox" value="true" name="read" checked>
                              <label class="form-check-label">Enable Show button in table</label>
                            </div>
                            <div class="form-check checkbox">
                              <input class="form-check-input" type="checkbox" value="true" name="edit" checked>
                              <label class="form-check-label">Enable Edit button in table</label>
                            </div>
                            <div class="form-check checkbox">
                              <input class="form-check-input" type="checkbox" value="true" name="add" checked>
                              <label class="form-check-label">Enable Add button in table</label>
                            </div>
                            <div class="form-check checkbox mb-3">
                              <input class="form-check-input" type="checkbox" value="true" name="delete" checked>
                              <label class="form-check-label">Enable Delete button in table</label>
                            </div>
                    
                    </div>
                    <div class="col-6">
                        <div class="card border-primary">
                            <div class="card-header">
                                <h4>Assign to roles:</h4>
                            </div>
                            <div class="card-body">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check checkbox mt-3">
                                        <input class="form-check-input" type="checkbox" value="true" name="_role_<?php echo e($role); ?>" checked>
                                        <label class="form-check-label"><?php echo e($role); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($column != 'id'): ?>
                                    <div class="card bg-light mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($column); ?></h5>
                                            <label>Visible name</label>
                                            <input 
                                                class="form-control" 
                                                name="<?php echo e($column); ?>_name" 
                                                type="text" 
                                                value="<?php echo e($column); ?>" 
                                                placeholder="Visible name"
                                            >
                                            <label>Field type</label>
                                            <select class="form-control" name="<?php echo e($column); ?>_field_type">
                                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option['value']); ?>"><?php echo e($option['name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label>Optional relation table name</label>
                                            <input 
                                                class="form-control" 
                                                name="<?php echo e($column); ?>_relation_table" 
                                                type="text" 
                                                placeholder="Optional relation table name"
                                            >
                                            <label>Optional column name in relation table - to print</label>
                                            <input 
                                                class="form-control" 
                                                name="<?php echo e($column); ?>_relation_column" 
                                                type="text" 
                                                placeholder="Optional column name in relation table - to print"
                                            >
                                            <div class="form-check checkbox">
                                                <input class="form-check-input" name="<?php echo e($column); ?>_browse" type="checkbox" value="true">
                                                <label class="form-check-label">Browse</label>
                                            </div>
                                            <div class="form-check checkbox">
                                                <input class="form-check-input" name="<?php echo e($column); ?>_read" type="checkbox" value="true">
                                                <label class="form-check-label">Read</label>
                                            </div>
                                            <div class="form-check checkbox">
                                                <input class="form-check-input" name="<?php echo e($column); ?>_edit" type="checkbox" value="true">
                                                <label class="form-check-label">Edit</label>
                                            </div>
                                            <div class="form-check checkbox">
                                                <input class="form-check-input" name="<?php echo e($column); ?>_add" type="checkbox" value="true">
                                                <label class="form-check-label">Add</label>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Save
                            </button>
                            <a 
                                href="<?php echo e(route('bread.create')); ?>"
                                class="btn btn-primary"
                            >
                                Return
                            </a>
                        </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\form\create2.blade.php ENDPATH**/ ?>