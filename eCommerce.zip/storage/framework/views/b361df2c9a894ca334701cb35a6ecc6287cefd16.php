<div class="container m-10">
    <?php if(session()->has('success_review')): ?>
        <div class="alert alert-success"><span><?php echo e(session('success_review')); ?></span></div>
    <?php endif; ?>
    <table class="table table-secondary">
        <thead>
            <tr >
                <th>№</th>
                <th>Image</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price Each</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-secondary">
                    <td><?php echo e($key+1); ?></td>
                    <td><img src="<?php echo e(asset('assets/images/products/'.$order_detail->product->image)); ?>" width="70" alt="<?php echo e($order_detail->product->name); ?>"></td>
                    <td><?php echo e($order_detail->product->name); ?></td>
                    <td><?php echo e($order_detail->quantity); ?></td>
                    <td>$<?php echo e($order_detail->price_each); ?></td>
                    <td>
                    <?php if($order_detail->order->status == 'delivered' && $order_detail->rstatus == 0): ?>
                        <a href="<?php echo e(route('reviews', ['order_details_id' => $order_detail->id])); ?>" class="btn btn-primary">Write Review</a>
                    <?php endif; ?>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\livewire\order-details-component.blade.php ENDPATH**/ ?>