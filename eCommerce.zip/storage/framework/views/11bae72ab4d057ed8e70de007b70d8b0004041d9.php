<div class="wrap-search center-section">
    <div class="wrap-search-form">
        <form action="#" id="form-search-top" name="form-search-top">
            <input type="text" name="search" value="" wire:model="search" placeholder="Search here...">
            <button form="form-search-top" type="button" wire:click="search()"><i class="fa fa-search" aria-hidden="true"></i></button>
            <div class="wrap-list-cate">
                
                <select class="link-control" wire:model="cat_name">
                    <option class="level-0" >All Category</option>
                    <?php if($categories): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="level-0" ><?php echo e($cat->slug); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </form>
    </div>
</div>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\livewire\search-header-component.blade.php ENDPATH**/ ?>