<div class="wrap-icon-section wishlist">
        
        <div class="topbar-menu-area">
                <div class="topbar-menu ">
                <ul>
                    <li class="menu-item menu-item-has-children parent" >
                        <?php if($wishlist): ?>
                        <a title="Dollar (USD)" href="#"><span class="index"><?php echo e($wishlist->count()); ?> item</span></a>
                        <?php else: ?>
                            <a title="Dollar (USD)" href="#"><span class="index">no wishlist</span></a>

                        <?php endif; ?>
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        <span class="title">Wishlist</span>
                        <?php if($wishlist): ?>
                        <ul class="submenu curency" >
                            <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="menu-item" style="width: 350px">
                                    <a title="Pound (GBP)" href="<?php echo e(route('product.detail', ['slug' => $item->product->slug])); ?>">
                                        <img width="50" src="<?php echo e(asset('assets/images/products/'.$item->product->image)); ?>" alt=""><?php echo e($item->product->name); ?> - <strong>$<?php echo e($item->product->price); ?></strong></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
</div>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\livewire\wishlist-count-component.blade.php ENDPATH**/ ?>