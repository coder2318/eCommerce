<?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label>Name</label>
                                <input class="form-control" type="text" placeholder="<?php echo e(__('Name')); ?>" name="name"  autofocus value="<?php echo e(isset($product) ? $product->name : old('name')); ?>">
                                <span style="color:red"><?php echo e($errors->first('name')); ?></span>
                            </div>

                            <div class="form-group row">
                                <label>Price</label>
                                <input class="form-control" type="number" placeholder="<?php echo e(__('Price')); ?>" name="price"  autofocus value="<?php echo e(isset($product) ? $product->price : old('price')); ?>">
                                <span style="color:red"><?php echo e($errors->first('price')); ?></span>
                            </div>

                            <div class="form-group row">
                                <label>Category</label>
                                <select class="form-control" name="category_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group row">
                                <label>Status</label>
                                <select class="form-control" name="status">

                                    <option value="insale">Insale</option>
                                    <option value="outsale">Outsale</option>

                                </select>
                            </div>

                            <div class="form-group row">
                                <label>Quantity</label>
                                <input class="form-control" type="number" placeholder="<?php echo e(__('Qunatity')); ?>" name="quantity"  autofocus value="<?php echo e(isset($product) ? $product->quantity : old('quantity')); ?>">
                                <span style="color:red"><?php echo e($errors->first('quantity')); ?></span>

                            </div>

                            <div class="form-group row">
                                <label>Short Description</label>
                                <textarea class="form-control" id="textarea-input" name="short_description" rows="9" placeholder="<?php echo e(__('Short Description..')); ?>"  value="<?php echo e(isset($product) ? $product->short_description : old('short_description')); ?>"></textarea>
                                <span style="color:red"><?php echo e($errors->first('short_description')); ?></span>
                            </div>

                            <div class="form-group row">
                                <label> Description</label>
                                <textarea class="form-control" id="textarea-input" name="description" rows="9" placeholder="<?php echo e(__('Description..')); ?>"  value="<?php echo e(old('description')); ?>"></textarea>
                                <span style="color:red"><?php echo e($errors->first('description')); ?></span>
                            </div>

                            


                            <div class="form-group row">
                                <label>Image</label>
                                <?php if(isset($product)): ?>
                                    <?php if($product->image): ?>
                                        <img src="<?php echo e(asset('assets/images/products/'.$product->image)); ?>" width="100" alt="<?php echo e($product->image); ?>">
                                    <?php endif; ?>

                                <?php endif; ?>
                                <input class="form-control" type="file"  name="image" >
                                <span style="color:red"><?php echo e($errors->first('image')); ?></span>
                            </div>

                            <div class="form-group row">
                                <label>Images</label>
                                <?php if(isset($product)): ?>
                                    <?php if($product->images): ?>
                                        <?php $images = explode(',', $product->images); ?>
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('assets/images/products/'.$item)); ?>" width="100" alt="<?php echo e($item); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <input class="form-control" type="file" multiple name="images[]" >
                                <span style="color:red"><?php echo e($errors->first('images')); ?></span>
                            </div>

                            <button class="btn btn-block btn-success" type="submit"><?php echo e(__('Add')); ?></button>
                            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-block btn-primary"><?php echo e(__('Return')); ?></a>
<?php /**PATH E:\OpenServer\domains\eCommerce\resources\views\dashboard\products\form.blade.php ENDPATH**/ ?>